
<?php include('head.php');?>

<?php include('header.php');?>
<?php include('sidebar.php');?>

 <?php
 include('connect.php');
 date_default_timezone_set('Asia/Kolkata');
 $current_date = date('Y-m-d');

 
     ?>



   


  <!-- Page wrapper  -->
        <div class="page-wrapper">
            <!-- Bread crumb -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">About us</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">About us</li>
                    </ol>
                </div>
            </div>
            <!-- End Bread crumb -->
           
		   <!-- my code start-->
		   <div class="feed-box text-center">
                            <section class="card">
                                <div class="card-body">
                                    <div class="corner-ribon blue-ribon">
                                        <i class="fa fa-twitter"></i>
                                    </div>
                                    <a href="#">
                                        <img class="align-self-center rounded-circle mr-3" style="width:85px; height:85px;" alt="" src="https://www.sourcecodester.com/sites/default/files/styles/thumbnail/public/pictures/picture-252843-1527103726.jpg?itok=FqR_A4Ux">
                                    </a>
                                    <h2>Mayuri K.</h2>
                                    <p>Please don't ask for Free Source Code as I really worked hard <br>to develop this project and please don't forget to like and share it if you found it useful :)</p>
                                  
								  <p class="text-primary"><b>
                                        For students or anyone else who needs program or source code for thesis writing or any Professional <br>Software Development, Website Development, Mobile Apps Development at affordable cost.<br> 
</b>
                                    </p>
									<div class="card bg-danger">
                            <div class="card-body">
                                <blockquote class="blockquote mb-0">
                                    <p class="text-light">contact me at</p>
                                    <footer class="blockquote-footer text-light">Email:  <cite title="Source Title">mayuri.infospace@gmail.com</cite>
									<br>
									<a href="https://www.instamojo.com/minfospace/" target="_blank"> Click here to visit my Online Store </a>
									</footer>
                                </blockquote>
								
                            </div>
                        </div>
                                </div>
                            </section>
                        </div>
		   <!--my code end-->
    

<?php include('footer.php');?>